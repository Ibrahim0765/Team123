package engine.board;

import java.util.ArrayList;
import java.util.Random;

import model.Colour;
import engine.GameManager;

public class Board implements BoardManager{
	private final GameManager gameManager;
	private final ArrayList<Cell> track;
	private final ArrayList<SafeZone> safeZones;
	private int splitDistance;
	
	public int getSplitDistance(){
		return splitDistance;
	}
	public void setSplitDistance(int splitDistance){
		this.splitDistance = splitDistance;
	}
	
	/*The track is made up of 100 cells ( excluding safe zones)
	*refer to the game description board for the visualization
	*starting from cell 0 we move in a clockwise fashion to cover the full board
	*the initialize safeZones function assigns the color of each player on the board
	**/
	public Board(ArrayList<Colour> colourOrder, GameManager gameManager){
		this.gameManager = gameManager;
		track = new ArrayList<Cell>();
		safeZones = new ArrayList<SafeZone>();
		splitDistance=3;
		initializeSafeZones(colourOrder);
		assignCellType(track);
		for(int i = 0 ; i < 8 ; i++)
			assignTrapCell();
	
	}
	
	private void assignCellType(ArrayList<Cell>	track ){
		for(int i = 0 ; i < 100 ; i++){
			if( i % 25 == 0)
				track.add(new Cell(CellType.BASE));
			else if( (i + 2) % 25 == 0)
				track.add(new Cell(CellType.ENTRY));
			else
				track.add(new Cell(CellType.NORMAL));
			
		}
	}
	
	private void initializeSafeZones(ArrayList<Colour> colourOrder ){
		for(int i = 0 ; i < colourOrder.size() ; i++){
			safeZones.add( new SafeZone ( colourOrder.get(i) ) );
		}
	}
	
	private void assignTrapCell(){
		Random randomCell = new Random();
		int newTrapIndex = randomCell.nextInt(100);
		while(track.get(newTrapIndex).getCellType() != CellType.NORMAL &&
			  track.get(newTrapIndex).isTrap()){
			
			newTrapIndex = randomCell.nextInt(100);
		}
		track.get(newTrapIndex).setTrap(true);
		
	}
	
	public ArrayList<Cell> getTrack(){
		return track;
	}
	
	public ArrayList<SafeZone> getSafeZones(){
		return safeZones;
	}
}
