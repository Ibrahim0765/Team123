package engine.board;

public enum CellType {
	NORMAL,SAFE,BASE,ENTRY;
}
