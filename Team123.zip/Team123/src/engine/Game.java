package engine;
import model.Colour;
import model.card.Card;
import model.card.Deck;

import java.util.ArrayList;
import java.util.Collections;

import model.player.CPU;
import model.player.Player;
import engine.board.Board;
import engine.board.BoardManager;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Game implements GameManager{
	private final Board board;
	private final ArrayList<Player> players;
	private final ArrayList<Card> firePit;
	private int currentPlayerIndex;
	private int turn;
	
	public Game(String playerName) throws IOException{
		ArrayList<Colour> colourOrder = createShuffledColours();
		board = new Board(colourOrder, this);
		Deck.loadCardPool(this.board , this);
		players = new ArrayList<>();
		initializePlayers(playerName , colourOrder);
		distributeCards();
		currentPlayerIndex = 0;
		turn = 0;
		firePit = new ArrayList<>();
	}
	
	private ArrayList<Colour> createShuffledColours(){
		ArrayList<Colour> colours = new ArrayList<>();
		colours.add(Colour.RED);
		colours.add(Colour.YELLOW);
		colours.add(Colour.GREEN);
		colours.add(Colour.BLUE);
		Collections.shuffle(colours);
		return colours;
	} 
	
	private void initializePlayers(String playerName , ArrayList<Colour> colourOrder){
		players.add(new Player(playerName, colourOrder.get(0)));
		players.add(new CPU("CPU 1", colourOrder.get(1), board));
		players.add(new CPU("CPU 2", colourOrder.get(2), board));
		players.add(new CPU("CPU 3", colourOrder.get(3), board));
	}
	
	private void distributeCards(){
		players.get(0).setHand(Deck.drawCards());
		players.get(1).setHand(Deck.drawCards());
		players.get(2).setHand(Deck.drawCards());
		players.get(3).setHand(Deck.drawCards());
	}
	
	public Board getBoard(){
		return board;
	}
	
	public ArrayList<Player> getPlayers(){
		return players;
	} 
	
	public ArrayList<Card> getFirePit(){
		return firePit;
	}
	
	public static void main(String[] args) {
		try {
			BufferedReader wawa  = new BufferedReader(new FileReader("Cards.csv"));
			wawa.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
