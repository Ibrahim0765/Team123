package model.card;
import model.card.Card;
import model.card.standard.Ace;
import model.card.standard.Five;
import model.card.standard.Four;
import model.card.standard.Jack;
import model.card.standard.King;
import model.card.standard.Queen;
import model.card.standard.Seven;
import model.card.standard.Standard;
import model.card.standard.Suit;
import model.card.standard.Ten;
import model.card.wild.Burner;
import model.card.wild.Saver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import engine.GameManager;
import engine.board.BoardManager;

public class Deck extends Card{
	private static final String CARDS_FILE = "Cards.csv";
	private static ArrayList<Card> cardsPool;
	
	public Deck(String name, String description, BoardManager boardManager,
				GameManager gameManager) {
		
		super(name, description, boardManager, gameManager);
	}

	public static void loadCardPool(BoardManager boardManager, GameManager gameManager)
					   				throws IOException{
		
		BufferedReader fileReader = new BufferedReader(new FileReader(CARDS_FILE));
		String cardInfo = fileReader.readLine();
		if(cardsPool == null)
			cardsPool = new ArrayList<>();
		
		 
		while(cardInfo != null){ // While the file still has content
			String[] cardSpecs = cardInfo.split(",");
			
			if(cardSpecs.length < 4) // Just a safety measure against file corruption , not a necessary check
				continue;
			
			int code = Integer.parseInt(cardSpecs[0].trim());
			int frequency = Integer.parseInt(cardSpecs[1].trim());
			String name = cardSpecs[2].trim();
			String description = cardSpecs[3];
			Card readCard;
			if(code >= 0 && code < 14){
				
				int rank = Integer.parseInt(cardSpecs[4].trim());
				Suit suit = Suit.valueOf(cardSpecs[5].trim());
				
				readCard = createCard(code, name, description,rank,suit, boardManager, gameManager);
				for (int i = 0; i < frequency; i++)
					cardsPool.add(readCard);
			}else{
				readCard = createCard(code, name, description, boardManager, gameManager);
				for (int i = 0; i < frequency; i++)
					cardsPool.add(readCard);
			}
			cardInfo = fileReader.readLine();
		}
		fileReader.close();
	}
	
	private static Card createCard(int code , String name , String description ,int rank,
								  Suit suit , BoardManager boardManager ,
								  GameManager gameManager ){
		switch(code){
			case 0 :
				return new Standard(name, description, rank, suit, boardManager, gameManager);
			case 1 :
				return new Ace(name, description, suit, boardManager, gameManager);
			case 4 :
				return new Four(name, description, suit, boardManager, gameManager);
			case 5 :
				return new Five(name, description, suit, boardManager, gameManager);
			case 7 :
				return new Seven(name, description, suit, boardManager, gameManager);
			case 10 :
				return new Ten(name, description, suit, boardManager, gameManager);
			case 11 :
				return new Jack(name, description, suit, boardManager, gameManager);
			case 12 :
				return new Queen(name, description, suit, boardManager, gameManager);
			case 13 :
				return new King(name, description, suit, boardManager, gameManager);
			default :
				throw new IllegalArgumentException();
		}
	}
	
	private static Card createCard(int code , String name , String description ,
								   BoardManager boardManager , GameManager gameManager){
		switch(code){
			case 14 :
				return new Burner(name, description, boardManager, gameManager);
			case 15 :
				return new Saver(name, description, boardManager, gameManager);
			default:
				throw new IllegalArgumentException();
		}
		


	}
	
	
	public static ArrayList<Card> drawCards(){
		Collections.shuffle(cardsPool);
		ArrayList<Card> drawnCards = new ArrayList<Card>();
		
		for(int i = 0 ; i < 4 ; i++)
			drawnCards.add(cardsPool.remove(0));
		
		return drawnCards;
	}
	
	
	
	
}
