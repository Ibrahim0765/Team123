package model.card.standard;

public enum Suit {
	HEART,DIAMOND,SPADE,CLUB;
}
