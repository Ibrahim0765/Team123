package model.player;
import java.util.ArrayList;

import model.card.Card;
import model.Colour;
public class Player  {
	private final String name;
	private final Colour colour;
    private ArrayList<Card> hand;
    private final ArrayList<Marble> marbles;
    private Card selectedCard;
    private final ArrayList<Marble> selectedMarbles;
    
    public Player(String name, Colour colour){
    	this.name= name;
    	this.colour= colour;
    	hand = new ArrayList<Card>();
    	marbles= new ArrayList<Marble>();
    	selectedMarbles = new ArrayList<Marble>();
    	
    	Marble marble_1= new Marble(colour);
    	Marble marble_2= new Marble(colour);
    	Marble marble_3= new Marble(colour);
    	Marble marble_4= new Marble(colour);
    	
    	marbles.add(marble_1);
    	marbles.add(marble_2);
    	marbles.add(marble_3);
    	marbles.add(marble_4);
    	
    	this.selectedCard = null;
    }
    
    public String getName(){
    	return this.name;
    }
    
    public Colour getColour(){
    	return colour;
    }
    
    public void setHand(ArrayList<Card> hand){
    	this.hand = hand;
    }
    
    public ArrayList<Card> getHand(){
    	return hand;
    }
    
    public ArrayList<Marble> getMarbles(){
    	return this.marbles;
    }
    
    public Card getSelectedCard(){
    	return this.selectedCard;
    }
}
