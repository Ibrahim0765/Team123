package exception;

public class InvalidCardException extends InvalidSelectionException {
	public InvalidCardException(){
		
	}
	
	public InvalidCardException(String message){
		super(message);
	}
	
	public static void main(String[] args){
		try{
			int x = 1;
			int y = 0;
			int z = x/y;
			System.out.println(1);
		}catch(Exception e){
			System.out.println("cant divide by 0");
		}
	}
}
