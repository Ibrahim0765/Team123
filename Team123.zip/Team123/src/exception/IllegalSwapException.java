package exception;

public class IllegalSwapException extends ActionException {
	public IllegalSwapException(){}
	
	public IllegalSwapException(String message){
		super(message);
	}
}
