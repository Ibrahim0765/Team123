package exception;

public class CannotDiscardException extends ActionException {
	public CannotDiscardException(){}
	
	public CannotDiscardException(String message){
		super(message);
	}
}
