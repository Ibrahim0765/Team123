package exception;

public class CannotFieldException extends ActionException {
	public CannotFieldException(){}
	
	public CannotFieldException(String message){
		super(message);
	}
}
